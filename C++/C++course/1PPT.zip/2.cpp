#include <iostream>                     //文件包含
using namespace std;                    // 使用命名空间
int main()                              // 主函数头
{                                       // 主函数体
    cout << "This is a C++ program.\n"; // 输出字符串
    return 0;
}
